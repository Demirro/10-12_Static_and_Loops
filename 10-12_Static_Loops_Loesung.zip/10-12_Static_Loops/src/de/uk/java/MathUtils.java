package de.uk.java;

public class MathUtils {

	public static int power (int basis, int exponent){
		int result = 1;
		
		while (exponent != 0) {
			result *= basis;
			--exponent;
		}
		/*
		for (int i = 1; i <= exponent; i++) {
			result *= basis;
		}
		*/
		return result;
	}
	
	public static int factorial (int number) {
		int result = 1;
		for (int i = 1; i <= number; i++) {
			result *= i;
		}
		return result;
	}
	
}
