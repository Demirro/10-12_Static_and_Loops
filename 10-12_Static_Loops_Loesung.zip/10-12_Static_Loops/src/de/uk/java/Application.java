package de.uk.java;

public class Application {

	public static void main(String[] args) {
		// Erwartete Ausgabe 16
		System.out.println(MathUtils.power(2, 4));
		// Erwartete Ausgabe 720
		System.out.println(MathUtils.factorial(6));
		}
}
